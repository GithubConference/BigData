"""
Created on Mon Apr  6 22:06:11 2020

@author: Gebruiker
"""

import numpy as np
import time
import statistics as s
from PIL.ImageFilter import FIND_EDGES
from numpy import asarray
from PIL import Image

path_infile = 'SimpleImgSeg/'
path_outfile = 'SimpleImgSegOut/'
exe = 'jpg'
n = 3

times = []

for i in range(0,n):
    im = Image.open(f'{path_infile}{i+1}.{exe}')
    # start timing
    start_time = time.time()
    # steps to look for edges in image
    grey = im.convert('L')
    rgb = im.getpixel((1, 1))
    data = np.asarray(im)[:,:,:]
    new_img = grey.filter(FIND_EDGES)
    data2 = np.asarray(new_img)[:,:]
    # only keep rows and columns with enough edges, based on size image
    x_new = data[np.sum(data2, axis=1) > (im.size)[1]*5]
    x_new = x_new[:,np.sum(data2, axis=0) > (im.size)[0]*5]
    im = Image.fromarray(x_new) 
    # end timer
    timer = time.time() - start_time
    times.append(timer)
    # save image
    im.save(f'{path_outfile}{i+1}.{exe}') 

# print average processing time    
mean = s.mean(times)
print(mean)