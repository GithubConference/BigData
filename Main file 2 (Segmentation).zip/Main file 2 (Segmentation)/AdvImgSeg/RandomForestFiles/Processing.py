# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 21:27:53 2020

@author: Gebruiker
"""
from PIL import Image
import numpy as np
from PIL.ImageFilter import (FIND_EDGES)
import pandas as pd

#
# FILE TO READ PIXELS FOR THE RANDOM FOREST
#
# choose label for whole file: 0 = no text, 1 = text
label = '1'
# choose name for outfile containing dataframe
outfile_name = 'notext.csv'

# open image and find edges
img = Image.open('test_text.jpg').convert('LA')
img = img.filter(FIND_EDGES)
np_im = np.array(img)
# take only one from third dimension      
np_im= np_im[:,:,0]

# specify size of blocks n times n
n = 128
# reshape image so it fits these blocks
x = ((np_im.shape[0]//n)+1)*n
y = ((np_im.shape[1]//n)+1)*n
zero_array = np.zeros((x, y))
zero_array[:np_im.shape[0], :np_im.shape[1]] = np_im
np_im = zero_array

# initiate dataframe
column_names = list(range(1, n*n+1))
random = list(range(1, n*n+1))
df = pd.DataFrame([random], columns = column_names)

# iterate over all the blocks
for i in range(0, np_im.shape[0], n):
  for j in range(0, np_im.shape[1], n):
      # extract the pixel values in indexed block
      data = np_im[i:i+n,j:j+n]
      data[0,0] = 0
      # turn to value between 0 and 1
      data = data / 255
      # turn to 1D array
      data_flat = data.flatten('C')
      # add pixel values to dataframe
      df2 = pd.DataFrame([data_flat],columns=column_names)
      df = pd.concat([df, df2], ignore_index=True)

df = df.drop(df.index[0])      

# add the label to the dataframe
df['label'] = label
df.to_csv(f'{outfile_name}') 


      


      


