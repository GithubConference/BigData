# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 15:28:26 2020

@author: Gebruiker
"""
import joblib
import pandas as pd
import numpy as np
from PIL import Image
import math

# load model
filename = 'RandomForestModel.sav'
loaded_model = joblib.load(filename)

# open df created by 'processing document'
df = pd.read_csv('example.csv')

import time
start_time = time.time()

# get predictions from model
pred_cols = list(df.columns.values)
pred = pd.Series(loaded_model.predict(df[pred_cols]))
a = pred.tolist()

# calculate amount of blocks in document
img = Image.open('example.jpg').convert('LA')
np_im = np.array(img)
rows = math.ceil(np_im.shape[0]/128)
columns = math.ceil(np_im.shape[1]/128)
#blocks = rows * columns

# create array to of predictions of each block fitting on image
a = np.array(a)
shape = ( rows, columns  )
data = a.reshape(shape, order='C' )

print("Processing time:", time.time() - start_time, "seconds")

