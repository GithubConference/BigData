#!/usr/bin/env python
# coding: utf-8

# In[188]:


#NB
# THIS CODE WAS PARTLY BASED ON THE SKLEARN RANDOM FOREST CLASSIFIER TUTORIAL https://www.youtube.com/watch?v=x9pIM2GkbF4

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


# In[189]:


data0 = pd.read_csv('notext.csv')
data1 = pd.read_csv('text.csv')

#data3 = pd.read_csv('test_notext.csv)
# create training data
data = pd.concat([data0, data1])


# In[190]:


data.head()


# In[191]:


data.tail()


# In[192]:


# select a flattened pixel block to test process
a = data.iloc[641,:-2].values


# In[193]:


import sys
import numpy
numpy.set_printoptions(threshold=sys.maxsize)


# In[194]:


# turn back into 2D block
import math
# size of block will be n times n
n = 128
a = a.astype('float')
a = a.reshape(n,n, order='C')
print(a)
print(a.shape)


# In[195]:


# show image
import matplotlib.cm as cm
plt.matshow(a, cmap='gray', vmin = 0, vmax=1)


# In[196]:


df_x = data.iloc[:,:-1]
df_y = data.iloc[:,-1]


# In[210]:


df_y


# In[211]:


test_data0 = pd.read_csv('test_notext.csv')
test_data1 = pd.read_csv('test_text.csv')
test_data = pd.concat([test_data0, test_data1])


# In[212]:


# create training and testing data
# train data
x_train = data.iloc[:,:-1]
# train labels 
y_train = data.iloc[:,-1]
# test data
x_test = test_data.iloc[:,:-1]
# test labels
y_test = test_data.iloc[:,-1]


# In[213]:


x_train.head()


# In[214]:


y_train.head()


# In[215]:


# specify classifier and choose amount of trees
rf=RandomForestClassifier(n_estimators = 1000)


# In[216]:


# fit model
rf.fit(x_train,y_train)


# In[227]:


# save the model to disk
import joblib
filename = 'RandomForestmodel.sav'
joblib.dump(rf, filename)


# In[217]:


y_test


# In[218]:


# make predictions for testing data
pred = rf.predict(x_test)


# In[219]:


pred


# In[220]:


# golden labels
y_test.values


# In[221]:


s = y_test.values
count=0


# In[222]:


for i in range(len(pred)):
    if pred[i] == s[i]:
        count = count+1


# In[223]:


# accuracy over test set
count/len(pred)


# In[ ]:




