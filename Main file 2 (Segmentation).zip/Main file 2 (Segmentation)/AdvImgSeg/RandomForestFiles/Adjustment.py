# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 17:40:13 2020

@author: Gebruiker
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import time

# this is a hardcoded array for the example, you can upload or hardcode other arrays here
hp = np.array([(1,1,1,1,1,0,0,0,0),
               (0,0,0,0,0,0,0,0,0),
               (0,0,0,0,0,0,0,0,0),
               (1,0,0,0,0,0,0,0,0),
               (1,1,0,0,0,0,0,1,1),
               (1,1,0,0,0,0,0,0,0),
               (1,1,0,0,0,0,0,0,0),
               (1,1,0,0,0,0,0,0,0),
               (1,1,1,1,1,0,0,0,0),
               (0,0,0,0,0,0,0,0,0),
               (0,0,0,0,0,0,0,0,0),
               (1,1,1,0,1,1,0,1,0)
              ])

#
img = Image.open('1.jpg').convert('LA')

# start timer to measure processing time
start_time = time.time()

# convert to array
np_im = np.array(img)

# take only one from third dimension      
np_im= np_im[:,:,0]

# set size of blocks n times n
n = 128
# resize image to fit block size
x = ((np_im.shape[0]//n)+1)*n
y = ((np_im.shape[1]//n)+1)*n

# overwrite original array over new array
zero_array = 255 * np.ones((x, y))
zero_array[:np_im.shape[0], :np_im.shape[1]] = np_im
np_im = zero_array

# adjust image based on text in blocks or not
def filter_img_blocks(n,x,y,np_im):
  # index the blocks to keep
  ind_array = []
  for dy in range(hp.shape[0]):
    vx = []
    for dx in range(hp.shape[1]):
      #print(dx,dy,hp[dy,dx])
      #data = np_im[n*dy:n*(dy+1),n*dx:n*(dx+1)]
      if hp[dy,dx]: vx.append((dx,dy))
    if vx: ind_array.append(vx)
  # put blocks in new position
  shift_img = 255 * np.ones((n*len(ind_array),n*max([len(x) for x in ind_array])))
  for i in range(len(ind_array)):
    for j in range(len(ind_array[i])):
      dx = ind_array[i][j][0]
      dy = ind_array[i][j][1]
      shift_img[n*i:n*(i+1),n*j:n*(j+1)] = np_im[n*dy:n*(dy+1),n*dx:n*(dx+1)]
  #imgplot = plt.imshow(shift_img)
  #print(type(shift_img))
  shift_img = (shift_img*255).astype(np.uint8)
  im = Image.fromarray(shift_img)
  im.save("1_new.jpg")
  plt.show()
  plt.close()

filter_img_blocks(n,x,y,np_im)

print("Processing time:", time.time() - start_time, "seconds")
