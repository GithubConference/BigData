# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 14:30:36 2020

@author: Gebruiker
"""
import time
import statistics as s
from PIL import Image

# specify amount of images and threshold
n = 10
threshold = 200
# specify paths and extensions
infile = 'GreyscaleANDBinarization/Covers/'
outfile_grey = 'GreyscaleANDBinarization/GreyOutCovers/'
outfile_bin = 'GreyscaleANDBinarization/BinOutCovers/'
in_exe = 'jpg'
out_exe = 'png'

# lists to keep track of processing times
times_grey = []
times_bin = []

# iterate over images
for i in range(0, n):
    #open image
    img = Image.open(f'{infile}{i+1}.{in_exe}')
    #convert to greyscale
    start_time = time.time()
    img_grey = img.convert('LA')
    timer = time.time() - start_time
    times_grey.append(timer)
    #convert to binary
    start_time = time.time()
    binarization = lambda x : 255 if x > threshold else 0
    img_bin = img.convert('L').point(binarization, mode='1')
    timer = time.time() - start_time
    times_bin.append(timer)
    #save both images
    img_grey.save(f'{outfile_grey}{i+1}.{out_exe}')
    img_bin.save(f'{outfile_bin}{i+1}.{out_exe}')
    
# print average processing times
mean_grey = s.mean(times_grey)
mean_bin = s.mean(times_bin)
print(mean_grey)
print(mean_bin)
    
  