# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 23:50:19 2020

@author: Gebruiker
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 14:30:36 2020

@author: Gebruiker
"""
from tesserocr import PyTessBaseAPI
import time
import pandas as pd
from difflib import SequenceMatcher
import statistics as s
from PIL import Image
import statistics as s
import matplotlib.pyplot as plt

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

n = 21
infile = 'NoisyData/'
outfile = 'BinOutNoisy/'
exe = 'png'


transcription = """A new offline handwritten database for the Spanish language
ish sentences, has recently been developed: the Spartacus databa
ish Restricted-domain Task of Cursive Script). There were two
this corpus. First of all, most databases do not contain Spani
Spanish is a widespread major language. Another important rea
from semantic-restricted tasks. These tasks are commonly used
use of linguistic knowledge beyond the lexicon level in the recog

As the Spartacus database consisted mainly of short sentence
paragraphs. the writers were asked to copy a set of sentences in f
line fields in the forms. Next figure shows one of the forms used
These forms also contain a brief set of instructions given to the
"""

thresholds = list(range(0, 255))
means = []
accs = []

for j in range(0, 255):
    print(f'threshold {j}')
    threshold = j
    times = []
    accuracies = []

    for i in range(0, n, 3):
        #open image
        img = Image.open(f'{infile}{i+1}.{exe}')
        #convert to binary
        binarization = lambda x : 255 if x > threshold else 0
        img_bin = img.convert('L').point(binarization, mode='1')
        img_bin.save(f'{outfile}{i+1}{threshold}.{exe}')
        start_time = time.time()
        with PyTessBaseAPI(path=r'C:\Users\Gebruiker\Desktop\Big Data\python\tessdata-master\tessdata-master', lang='eng') as api:
            api.SetImageFile(f'{outfile}{i+1}{threshold}.{exe}')
            outcome = api.GetUTF8Text()
        timer = time.time() - start_time
        times.append(timer)
            #save both images
        acc = similar(transcription, outcome)
        accuracies.append(acc)
    
    mean_time = s.mean(times)
    mean_acc = s.mean(accuracies)
    means.append(mean_time)
    accs.append(mean_acc)
    
print(thresholds)
print(means)
print(accs)
print(len(thresholds))
print(len(means))
print(len(accs))

#plt.plot(thresholds, means)
#plt.show()
#plt.plot(thresholds, accs)
#plt.show()

x = thresholds
data1 = means
data2 = accs

fig, ax1 = plt.subplots()

color = 'tab:red'
ax1.set_xlabel('threshold')
ax1.set_ylabel('time in seconds', color=color)
ax1.plot(x, data1, color=color)
ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

color = 'tab:blue'
ax2.set_ylabel('accuracy', color=color)  # we already handled the x-label with ax1
ax2.plot(x, data2, color=color)
ax2.tick_params(axis='y', labelcolor=color)

fig.tight_layout()  # otherwise the right y-label is slightly clipped
plt.show()
    
  