# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 14:30:36 2020

@author: Gebruiker
"""
from tesserocr import PyTessBaseAPI
import time
import pandas as pd
from difflib import SequenceMatcher
import statistics as s
import chardet

# function for accuracy evaluation
def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

# define path, extension and amount of pictures
path = 'SimpleImgSegOut/'
exe = 'jpg'
n= 3

# open file with transcriptions
with open(f'{path}Transcriptions.csv', 'rb') as f:
    result = chardet.detect(f.read())
df = pd.read_csv(f'{path}Transcriptions.csv', encoding=result['encoding'])

# initialize dataframe for outcomes
data = [['.', '.']] 
# Create the pandas DataFrame 
column_names = ['Time', 'Accuracy']
new_df = pd.DataFrame(data, columns = column_names) 
 
# loop for reading and evaluating images
for i in range(0, n):
    # reading and measuring reading time
    start_time = time.time()
    with PyTessBaseAPI(path=r'C:\Users\Gebruiker\Desktop\Big Data\python\tessdata-master\tessdata-master', lang='eng') as api:
        api.SetImageFile(f'{path}{i+1}.{exe}')
        outcome = api.GetUTF8Text()
    timer = time.time() - start_time
    # accuracy evaluation
    transcription = df['Transcription'][i]
    acc = similar(transcription, outcome)
    # add new variables to dataframe
    new_data = [[timer, acc]]
    df2 = pd.DataFrame(new_data,columns=column_names)
    new_df = pd.concat([new_df, df2], ignore_index=True)

# aggregate statistics on dataframe    
new_df = new_df.drop(new_df.index[0])
mean_time = s.mean(new_df['Time'])
mean_acc = s.mean(new_df['Accuracy'])
new_df.loc['mean'] = [mean_time,mean_acc]
# print final results
print(new_df)

# calculate time-accuracy ratio
print('ratio:', mean_acc/mean_time)


    
