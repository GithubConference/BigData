# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 22:06:11 2020

@author: Gebruiker
"""
# NB
# THIS CODE IS PARTLY BASED ON THE TUTORIAL https://www.pyimagesearch.com/2017/02/20/text-skew-correction-opencv-python/

import numpy as np
import cv2
import time
import statistics as s

path_infile = 'SkewCorr/'
path_outfile = 'SkewCorrOut/'
exe = 'jpg'
n = 16

times = []

for i in range(0,n):
    image = cv2.imread(f'{path_infile}{i+1}.{exe}')
    # start timing
    start_time = time.time()
    #convert to black-and-white, ensure white background
    img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    img = cv2.bitwise_not(img)
    ret, thresh = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
    
    # find coordinates and angle of non-white surface
    coords = np.column_stack(np.where(thresh > 0))
    angle = cv2.minAreaRect(coords)[-1]
    # the `cv2.minAreaRect` function returns values in the
    # range [-90, 0); as the rectangle rotates clockwise the
    # returned angle trends to 0 -- in this special case we
    # need to add 90 degrees to the angle
    if angle < -45:
        angle = -(angle+90)
    # otherwise, make the angle positive
    else:
        angle=abs(angle)
    
    # rotate the image
    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(image, M, (w, h),
    flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    
    # end timer
    timer = time.time() - start_time
    times.append(timer)
    # save image
    cv2.imwrite(f'{path_outfile}{i+1}.{exe}', rotated) 
    # ability to show image turned of below
    #cv2.imshow("Rotated", rotated)
    #cv2.waitKey(0)

# print average processing time    
mean = s.mean(times)
print(mean)